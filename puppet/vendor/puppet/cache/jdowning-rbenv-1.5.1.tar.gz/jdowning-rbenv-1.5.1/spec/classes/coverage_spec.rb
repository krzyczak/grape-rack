at_exit { RSpec::Puppet::Coverage.report! }
