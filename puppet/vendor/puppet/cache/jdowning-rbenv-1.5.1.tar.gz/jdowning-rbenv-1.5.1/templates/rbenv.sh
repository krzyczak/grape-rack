export RBENV_ROOT=<%= @install_dir %>
export PATH="$RBENV_ROOT/bin:$PATH"
eval "$(rbenv init -)"
